#include<stdio.h>
int prime(int n){
int flag=0;
  int i;
for(i=2;i<=n-i;i++){
if(n%i==0){
  flag=1;
  break;
}
  }
  if(flag==0){
    printf("prime number");
    }
  else{
    printf("not prime number");
    }
  }
  int main()
{
  int a;
  printf("enter the number:");
  scanf("%d",&a);
  
  prime(a);
    
  return 0;
  }
  