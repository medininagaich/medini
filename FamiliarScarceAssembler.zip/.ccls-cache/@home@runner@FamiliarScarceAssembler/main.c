#include<stdio.h>
int mean(int a1,int a2,int a3,int a4,int a5)
{
  int sum=0;
  int i;
  for(i=1;i<=5;i++){
  sum=sum+i;
    }
    mean=sum/5;
    
  return mean(a1,a2,a3,a4,a5);
  
}
int main(){
  int i,n,s;
  printf("enter the 5 numbers:\n");
  for(i=1;i<=5;i++){
    printf("%d",n);
  }
  return mean(s,n);
}